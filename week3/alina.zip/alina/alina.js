function RevealMessage()
{
    document.getElementById("HiddenMsg").style.display="block";
}

function CountDown()
{
    if( document.getElementById("countDown").innerHTML>0)
    document.getElementById("countDown").innerHTML-=1;
}